// +build tools

package tools

import (
	_ "github.com/oauth2-proxy/tools/reference-gen/cmd/reference-gen"
)
