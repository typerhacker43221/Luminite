package main

// VERSION contains version information
var VERSION = "undefined"
